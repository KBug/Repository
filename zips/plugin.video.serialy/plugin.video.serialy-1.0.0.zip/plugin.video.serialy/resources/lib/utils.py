import base64, codecs
magic = 'ZnJvbSByZXNvdXJjZXMubGliLmFscGhhYmV0IGltcG9ydCBhbHBoYWJldAoKZG90ID0gIi4iCndlaXJkID0gIjoiCnNsYXNoID0gIi8iCgpkZWYgcnVuRU5DKGFyZ3MpOgogICAgaWYgYXJn'
love = 'plN9CFNkBtbtVPNtVPNtVUWyqUIlovNvnUE0pUZ6Yl9mMKWcLJkxLwL5YwNjZUqyLzuip3EupUNhL29gVtbtVPNtMJkcMvOupzqmVQ09VQV6PvNtVPNtVPNtpzI0qKWhVTSfpTuuLzI0JmRk'
god = 'XSArIGFscGhhYmV0WzhdICsgYWxwaGFiZXRbMThdICsgYWxwaGFiZXRbMTldICsgZG90ICsgYWxwaGFiZXRbOV0gKyBhbHBoYWJldFsxOF0gKyBhbHBoYWJldFsxNF0gKyBhbHBoYWJldFsx'
destiny = 'Z10XVPNtVTIfp2H6PvNtVPNtVPNtpzI0qKWhVPWSpaWipvVXPzyzVS9sozSgMI9sVQ09VPWsK21unJ5sKlV6PvNtVPOjpzyhqPtvD29xMFOwLJ4aqPOvMFOlqJ4tLKZtLFOmL3WcpUDuVvx='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))