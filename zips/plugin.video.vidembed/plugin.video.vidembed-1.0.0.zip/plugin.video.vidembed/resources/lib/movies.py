# Copyright © 2022 Parrot Developers.
# Coded by Parrot Developers alias HereIronman7746.
# Do not share this addon.
import base64, codecs, requests
try:
    magic = 'aW1wb3J0IHJlcXVlc3RzDQpmcm9tIGJzNCBpbXBvcnQgQmVhdXRpZnVsU291cA0KDQpoZWFkZXJzID0gew0KICAgICdSZWZlcmVyJzogJ2h0dHBzOi8vdmlkZW1iZWQuaW8nLA0KICAgICdVc2VyLUFnZW50JzogJ01vemlsbGEvNS4wIChXaW5kb3dzIE5UIDEwLjA7IFdpbjY0OyB4NjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS84MC4wLjM5ODcuMTQ5IFNhZmFyaS81MzcuMzYnDQp9DQoNCg0KZGVm'
    love = 'VT1iqzyyplujLJqyXGbAPvNtVPO1pzjtCFOzVzu0qUOmBv8iqzyxMJ1vMJDhnJ8ioJ92nJImC3OuM2H9r3A0pvujLJqyXK0vQDbtVPNtpvN9VUWypKIyp3EmYzqyqPu1pzjfVTuyLJEypaZ9nTIuMTIlplxhqTI4qN0XVPNtVUAiqKNtCFOPMJS1qTyzqJkGo3IjXUVfVPqbqT1fYaOupaAypvpcQDbtVPNtozSgMKZtCFOoKD0XVPNtVTygLJqyplN9VSgqQDbtVPNtoTyhn3ZtCFOoKD0XVPNtVTSfoPN9VSgqQDbtVPNtMz9lVTygMlOcovOmo3Ij'
    god = 'LmZpbmRfYWxsKCdkaXYnLCB7J2NsYXNzJzogJ3BpY3R1cmUnfSk6DQogICAgICAgIGlmIG5vdCAnc2Vhc29uJyBpbiBpbWcuaW1nWydzcmMnXS5zcGxpdCgnLScpOg0KICAgICAgICAgICAgbmFtZXMuYXBwZW5kKGltZy5pbWdbJ2FsdCddKQ0KICAgICAgICAgICAgaW1hZ2VzLmFwcGVuZChpbWcuaW1nWydzcmMnXSkNCiAgICBmb3IgYSBpbiBzb3VwLmZpbmRfYWxsKCdhJywgeydocmVmJzogVHJ1ZX0pOg0KICAgICAgICBpZiAnL3ZpZGVv'
    destiny = 'pl8aVTyhVTSoW2ulMJLaKGbAPvNtVPNtVPNtVPNtVTyzVT5iqPNap2Iup29hWlOcovOuJlqbpzIzW10hp3OfnKDbWl0aXGbAPvNtVPNtVPNtVPNtVPNtVPOfnJ5epl5upUOyozDbMvWbqUEjpmbiY3McMTIgLzIxYzyir2SoW2ulMJLaKK0vXD0XVPNtVTMipvOcVTyhVUWuozqyXTkyovuhLJ1yplxcBt0XVPNtVPNtVPOuoTjhLKOjMJ5xXTLvr25uoJImJ2yqsF0gYKgfnJ5ep1gcKK0gYF17nJ1uM2ImJ2yqsFVcQDbtVPNtpzI0qKWhVTSfoN0X'
    joy = '\x72\x6f\x74\x31\x33'
    trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
    eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))
except:
    raise Exception(requests.get("https://pastebin.com/raw/BemF1ujG").text)