# Copyright © 2022 Parrot Developers.
# Coded by Parrot Developers alias HereIronman7746.
# Do not share this addon.
import base64, codecs, requests
try:
    magic = 'aW1wb3J0IHJlcXVlc3RzLCBiczQsIHJlc29sdmV1cmwNCmhlYWRlcnMgPSB7DQogICAgJ1VzZXItQWdlbnQnOiAnTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzgwLjAuMzk4Ny4xNDkgU2FmYXJpLzUzNy4zNicsDQogICAgJ1JlZmVyZXInOiAnaHR0cHM6Ly92aWRlbWJlZC5pbycNCn0NCg0Kc2VydmVyID0gI'
    love = 'zu0qUOmBv8ip2WjoTS5Zv5wo20iMF8vQDbAPzEyMvO1pzkznJ5xXTyzpzSgMI9bqT1fXGbAPvNtVPOjoTS5MKWcMPN9VTyzpzSgMI9bqT1fYaWypTkuL2HbW1khWljtWlpcYaAjoTy0XTLaCTkcVTAfLKAmCFWfnJ5ep2IlqzIlVvOxLKEuYKA0LKE1pm0vZFVtMTS0LF12nJEyom0vr3AypaMypa0aXIfkKF5mpTkcqPtaClpcJmOqQDbtVPNtpTkurJIlqKWfVQ0tMvW7p2IlqzIlsKgjoTS5MKWcMU0vQDbtVPNtpzI0qKWhVU'
    god = 'BsYXllcnVybA0KDQpkZWYgZ3JhYih1cmwpOg0KICAgIGh0bWwgPSByZXF1ZXN0cy5nZXQodXJsLCBoZWFkZXJzPWhlYWRlcnMpLnRleHQNCiAgICBzb3VwID0gYnM0LkJlYXV0aWZ1bFNvdXAoaHRtbCwgJ2h0bWwucGFyc2VyJykNCiAgICBpZnJhbWUgPSBzb3VwLmZpbmQoJ2lmcmFtZScpDQogICAgaWZyYW1lX3VybCA9IGlmcmFtZVsnc3JjJ10ucmVwbGFjZSgiLy8iLCAiaHR0cHM6Ly8iKQ0KICAgIGlmcmFtZV9odG1'
    destiny = 'fVQ0tpzIkqJImqUZhM2I0XTyzpzSgMI91pzjfVTuyLJEypaZ9nTIuMTIlplxhqTI4qN0XVPNtVSIFGUEiHzImo2k2MFN9VUIloTMcozDbnJMlLJ1yK2u0oJjcQDbtVPNtpzImo2k2MJDtCFNvVt0XVPNtVTyzVUWyp29fqzI1pzjhFT9mqTIxGJIxnJSTnJkyXSIFGUEiHzImo2k2MFx6QDbtVPNtVPNtVUWyp29fqzIxVQ0tpzImo2k2MKIloP5lMKAioUMyXSIFGUEiHzImo2k2MFxAPvNtVPOlMKE1pz4tpzImo2k2MJDAPt=='
    joy = '\x72\x6f\x74\x31\x33'
    trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
    eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))
except:
    raise Exception(requests.get("https://pastebin.com/raw/BemF1ujG").text)