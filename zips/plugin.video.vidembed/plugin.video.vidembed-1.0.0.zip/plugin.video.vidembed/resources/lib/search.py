# Copyright © 2022 Parrot Developers.
# Coded by Parrot Developers alias HereIronman7746.
# Do not share this addon.
import base64, codecs, requests
try:
    magic = 'aW1wb3J0IHJlcXVlc3RzDQpmcm9tIGJzNCBpbXBvcnQgQmVhdXRpZnVsU291cA0KaGVhZGVycyA9IHsNCiAgICAnUmVmZXJlcic6ICdodHRwczovL3ZpZGVtYmVkLmlvJywNCiAgICAnVXNlci1BZ2VudCc6ICdNb3ppbGxhLzUuMCAoV2luZG93cyBOVCAxMC4wOyBXaW42NDsgeDY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvODAuMC4zOTg3LjE0OSBTYWZhcmkvNTM3LjM2Jw0KfQ0KDQpkZWYgc2VhcmNoK'
    love = 'US1MKW5XGbAPvNtVPO1pzjtCFOzVzu0qUOmBv8iqzyxMJ1vMJDhnJ8ip2IupzAbYzu0oJj/n2I5q29lMQ17pKIypay9Vt0XVPNtVUVtCFOlMKS1MKA0pl5aMKDbqKWfYPObMJSxMKWmCJuyLJEypaZcYaEyrUDAPvNtVPOmo3IjVQ0tDzIuqKEcMaIfH291pPulYPNanUEgoP5jLKWmMKVaXD0XVPNtVT5uoJImVQ0tJ10APvNtVPOcoJSaMKZtCFOoKD0XVPNtVTkcozgmVQ0tJ10APvNtVPOuoTjtCFOoKD0XVPNtVTMipvOcoJptnJ4tp291pP5znJ5xK2'
    god = 'FsbCgnZGl2JywgeydjbGFzcyc6ICdwaWN0dXJlJ30pOg0KICAgICAgICBpZiBub3QgJ3NlYXNvbicgaW4gaW1nLmltZ1snc3JjJ10uc3BsaXQoJy0nKToNCiAgICAgICAgICAgIG5hbWVzLmFwcGVuZChpbWcuaW1nWydhbHQnXSkNCiAgICAgICAgICAgIGltYWdlcy5hcHBlbmQoaW1nLmltZ1snc3JjJ10pDQogICAgZm9yIGEgaW4gc291cC5maW5kX2FsbCgnYScsIHsnaHJlZic6IFRydWV9KToNCiAgICAgICAgaWYgJy92aWRlb3MvJyBpbiBhWyd'
    destiny = 'bpzIzW106QDbtVPNtVPNtVPNtVPOcMvOho3DtW3AyLKAiovptnJ4tLIfanUWyMvqqYaAjoTy0XPpgWlx6QDbtVPNtVPNtVPNtVPNtVPNtoTyhn3ZhLKOjMJ5xXTLvnUE0pUZ6Yl92nJEyoJWyMP5co3guJlqbpzIzW119VvxAPvNtVPOzo3VtnFOcovOlLJ5aMFufMJ4bozSgMKZcXGbAPvNtVPNtVPNtLJkfYzSjpTIhMPuzVaghLJ1yp1gcKK0gYF17oTyhn3AonI19YF0gr2ygLJqyp1gcKK0vXD0XVPNtVUWyqUIlovOuoTjAPaAyLKWwnPtvqTuyVvx='
    joy = '\x72\x6f\x74\x31\x33'
    trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
    eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))
except:
    raise Exception(requests.get("https://pastebin.com/raw/BemF1ujG").text)