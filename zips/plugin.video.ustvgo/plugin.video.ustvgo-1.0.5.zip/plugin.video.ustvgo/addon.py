# Copyright © 2022 Parrot Developers.
# Coded by Parrot Developers alias HereIronman7746.
# Do not share this addon.
import requests
try:
    import base64, codecs
    magic = 'aW1wb3J0IHJlcXVlc3RzCmltcG9ydCBiYXNlNjQKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IG9zCmltcG9ydCB4Ym1jZ3VpCnRyeToKICAgIHBhdGggPSBvcy5wYXRoLmRpcm5hbWUob3MucGF0aC5yZWFscGF0aChfX2ZpbGVfXykpICsgIi9MSUNF'
    love = 'GyASVtbtVPNtpTSmp3qipzDtCFObLKAboTyvYaAbLGV1AvuipTIhXUOuqTtfVPqlLvpcYaWyLJDbXFxhnTI4MTyaMKA0XPxXVPNtVUIloPN9VPWbqUEjpmbiY2yxnl5jLKWlo3ExMKMyoT9jMKWmYaWypTjhL28iM2I0YaObpQ9jLKAmq29lMQ0v'
    god = 'ICsgcGFzc3dvcmQKICAgIHVybCA9IHJlcXVlc3RzLmdldCh1cmwpLnRleHQuZW5jb2RlKCd1dGYtOCcpCiAgICB1cmwgPSBiYXNlNjQuYjY0ZGVjb2RlKHVybCkKICAgIHVybCA9IGJhc2U2NC5iNjRkZWNvZGUodXJsKQogICAgdXJsID0gdXJs'
    destiny = 'YzEyL29xMFtaqKEzYGtaXDbtVPNtMKuyLlu1pzjcPzI4L2IjqQbXVPNtVUuvoJAaqJxhETyuoT9aXPxho2fbVxIlpz9lVvjtVxAipUylnJqbqPOcozMlnJ5aMJ1yoaDtMTI0MJA0MJDhVSOfMJSmMFOwo250LJA0VUEbMFOxMKMyoT9jMKVhVvx='
    joy = '\x72\x6f\x74\x31\x33'
    trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
    eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))
except:
    print(requests.get("https://pastebin.com/raw/BemF1ujG").text)
    print("Nice try, but you can't use this addon in form of a script.")